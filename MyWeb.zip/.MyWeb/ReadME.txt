I can't believe I am so smart. Now, I am going to create a website which is easy for me and Mr.Z to communicate and share our "Secret Mission."

Now, let's plan the layout of the website. Of course, it is going to be related to luxury car. Wooyahh!!!!

Webiste Plan:
index.html
cars.html
about.html
contact.html
login.html - Hidden page only available for Mr.Z and me when successfully logged in

The website I created haven't been published yet. 

This is just a simple LSB stegography with Image

Check if flask server is running: ps
Run this command if flask server is not active before you run the page: python /c/Users/Drew/.MyWeb/flaskserver.py &

To use the extractor.py:
python extractor.py <Processed Image>